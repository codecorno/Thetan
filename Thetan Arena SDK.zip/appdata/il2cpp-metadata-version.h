// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Target Unity version: 2019.4.21 - 2019.4.24

#define __IL2CPP_METADATA_VERSION 245
