// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Helper functions

#pragma once

#include <string>
#include <sstream>
#include <iomanip>

#include "il2cpp-metadata-version.h"
#include "dxIndex.h"
#include "D3D11.h"
#include <D3Dcompiler.h>

#pragma comment (lib, "D3DCompiler.lib")
#pragma comment (lib, "D3D11.lib")

// Helper function to get the module base address
uintptr_t il2cppi_get_base_address();

// Helper function to append text to a file
void il2cppi_log_write(std::string text);

// Helper function to open a new console window and redirect stdout there
void il2cppi_new_console();

#if _MSC_VER >= 1920
// Helper function to convert Il2CppString to std::string
std::string il2cppi_to_string(Il2CppString* str);

// Helper function to convert System.String to std::string
std::string il2cppi_to_string(app::String* str);
#endif

// Helper function to check if a metadata usage pointer is initialized
template<typename T> bool il2cppi_is_initialized(T* metadataItem) {
#if __IL2CPP_METADATA_VERISON < 270
    return *metadataItem != 0;
#else
    // Metadata >=27 (Unity 2020.2)
    return !((uintptr_t) *metadataItem & 1);
#endif
}

// Helper function to convert a pointer to hex
template<typename T> std::string to_hex_string(T i) {
    std::stringstream stream;
    stream << "0x" << std::setfill('0') << std::setw(sizeof(T) * 2) << std::hex << i;
    return stream.str();
}

typedef HRESULT(__fastcall* IDXGISwapChainPresent)(IDXGISwapChain* pSwapChain, UINT syncInterval, UINT flags);
typedef void(__stdcall* ID3D11DrawIndexed)(ID3D11DeviceContext* pDeviceContext, UINT indexCount, UINT startIndexLocation, INT baseVertexLocation);
#define SleepUntil(STATE, INTERVAL) while (!##STATE##) { Sleep(##INTERVAL##); }

namespace Util
{
	inline bool SetupConsole()
	{
		const bool result = AllocConsole();

		if (result)
		{
			FILE* pFile = nullptr;
			freopen_s(&pFile, "CONOUT$", "w", stdout);
			freopen_s(&pFile, "CONOUT$", "w", stderr);
			freopen_s(&pFile, "CONIN$", "r", stdin);

			SetConsoleTitle(L"DirectX 11 Hook");
		}

		return result;
	}

	inline bool ReleaseConsole()
	{
		const bool result = FreeConsole();

		if (result)
		{

		}

		return result;
	}
}