// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Custom injected code entry point

#include "pch-il2cpp.h"

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <unordered_set>
#include <mutex>
#include "il2cpp-appdata.h"
#include "helpers.h"
#include "detours.h"

#include "D3D11.h"
#include <D3Dcompiler.h>

#pragma comment (lib, "D3DCompiler.lib")
#pragma comment (lib, "D3D11.lib")
#pragma comment (lib, "winmm.lib")
#pragma comment (lib, "user/detours.lib")

#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_win32.h"
#include "../imgui/imgui_impl_dx11.h"
#include "helpers.h"

using namespace app;

extern const LPCWSTR LOG_FILE = L"il2cpp-log.txt";

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK hWndProc(HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam);

bool WINAPI GetSwapChainVTable();
void PrintRVA();
void ConfigureGUIStyle();



HWND window = nullptr;
WNDPROC originWndProcHandler = nullptr;



bool bShowMenu = false;
bool bPresentInitialized = false;


bool bCreateThread = true;


bool bUseConsole = true;


bool bCloseConsoleAfterInit = true;


bool bPrintRVA = true;


UINT menuKey = VK_INSERT;



ID3D11Device* pDevice;
ID3D11DeviceContext* pDeviceContext;
ID3D11RenderTargetView* pTargetRT;
IDXGISwapChain* pSwapChain;



DWORD_PTR* pDeviceContextVTable = nullptr;
DWORD_PTR* pSwapChainVTable = nullptr;

ImFont* m_default = nullptr;
ImFont* g_font;
ImFont* t_font;
IDXGISwapChainPresent fnIDXGISwapChainPresent;
HRESULT __fastcall onPresent(IDXGISwapChain* _chain, UINT syncInterval, UINT flags);

bool InitializePresent(IDXGISwapChain* pChain, UINT SyncInterval, UINT Flags);

void Run()
{
    il2cpp_thread_attach(il2cpp_domain_get());
	bool result;


	if (bUseConsole)
	{
		result = Util::SetupConsole();
		if (!result)
		{
			std::cout << "[-] Console already allocated!" << std::endl;
		}
		else
		{
			std::cout << "[+] Console alloced successfully." << std::endl;
		}
	}


	result = GetSwapChainVTable();
	if (!result)
	{
		std::cout << "[-] Hooking virtual table failed!" << std::endl;
		system("pause");
		return;
	}

	try
	{
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());
		DetourAttach(&(LPVOID&)fnIDXGISwapChainPresent, (PBYTE)onPresent);
		DetourTransactionCommit();
	}
	catch (int e)
	{
		std::cout << "[-] SwapChainPresent detour failed : " << e << std::endl;
		return;
	}

	SleepUntil(bPresentInitialized, 100)

		if (bPrintRVA)
		{
			PrintRVA();
		}

	Sleep(100);

	if (bUseConsole && bCloseConsoleAfterInit)
	{
		result = Util::ReleaseConsole();
		if (!result)
		{
			std::cout << "[-] Console deallocation failed!" << std::endl;
			system("pause");
			return;
		}
	}

	std::cout << "[+] Successfully hooked!" << std::endl;

	RuntimeConfig_GetRuntimPlayerByIndex(RuntimeConfig * __this, int32_t index, MethodInfo * method);

}


LRESULT CALLBACK hWndProc(HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	POINT mPos;

	GetCursorPos(&mPos);
	ScreenToClient(window, &mPos);

	ImGui::GetIO().MousePos.x = (float)mPos.x;
	ImGui::GetIO().MousePos.y = (float)mPos.y;

	if (uMessage == WM_KEYUP)
	{
		if (wParam == menuKey)
		{
			bShowMenu = !bShowMenu;
		}
	}

	if (bShowMenu)
	{
		ImGui_ImplWin32_WndProcHandler(hwnd, uMessage, wParam, lParam);
		return true;
	}

	return CallWindowProc(originWndProcHandler, hwnd, uMessage, wParam, lParam);
}


bool WINAPI GetSwapChainVTable()
{
	HRESULT result;

	WNDCLASSEX wc = {
		sizeof(WNDCLASSEX), CS_CLASSDC,
		[](const HWND hwnd, const UINT uMessage, const WPARAM wParam, const LPARAM lParam)
		{
			return DefWindowProc(hwnd, uMessage, wParam, lParam);
		},
		0L, 0L, GetModuleHandle(nullptr),
		nullptr, nullptr, nullptr, nullptr,
		L"DX", nullptr
	};

	RegisterClassEx(&wc);

	HWND hWnd = CreateWindow(L"DX", NULL, WS_OVERLAPPEDWINDOW,
		100, 100, 300, 300, NULL, NULL, wc.hInstance, NULL);

	DXGI_SWAP_CHAIN_DESC swapChainDesc;
	ZeroMemory(&swapChainDesc, sizeof(swapChainDesc));

	swapChainDesc.BufferCount = 1;
	swapChainDesc.BufferDesc.Width = 2;
	swapChainDesc.BufferDesc.Height = 2;
	swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;

	swapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
	swapChainDesc.BufferDesc.RefreshRate.Numerator = 60;

	swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapChainDesc.OutputWindow = hWnd;

	swapChainDesc.SampleDesc.Count = 1;
	swapChainDesc.SampleDesc.Quality = 0;
	swapChainDesc.Windowed = TRUE;
	swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

	D3D_FEATURE_LEVEL requestedFeatureLevel = D3D_FEATURE_LEVEL_11_0;
	const UINT nRequestedFeatureLevel = 1;

	D3D_FEATURE_LEVEL supportedFeatureLevel;
	IDXGISwapChain* swapChain = nullptr;
	ID3D11Device* device = nullptr;
	ID3D11DeviceContext* deviceContext = nullptr;

	result = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
		&requestedFeatureLevel, nRequestedFeatureLevel, D3D11_SDK_VERSION,
		&swapChainDesc, &swapChain, &device, &supportedFeatureLevel, &deviceContext);

	if (FAILED(result))
	{
		std::cout << "[-] D3D11CreateDeviceAndSwapChain failed!" << std::endl;
		return false;
	}


	pSwapChainVTable = (DWORD_PTR*)swapChain;
	pSwapChainVTable = (DWORD_PTR*)pSwapChainVTable[0];

	fnIDXGISwapChainPresent = (IDXGISwapChainPresent)(DWORD_PTR)pSwapChainVTable[SC_PRESENT];
	std::cout << "[+] D3D11 present hooked!" << std::endl;

	if (bCreateThread)
	{
		Sleep(2000);
	}

	return true;
}

HRESULT __fastcall onPresent(IDXGISwapChain* _chain, UINT syncInterval, UINT flags)
{
	bool result;
	if (!bPresentInitialized)
	{
		result = InitializePresent(_chain, syncInterval, flags);
		if (!result)
		{
			return fnIDXGISwapChainPresent(_chain, syncInterval, flags);
		}
	}

	ImGui::CreateContext();

	ImGui_ImplWin32_NewFrame();
	ImGui_ImplDX11_NewFrame();

	ImGui::NewFrame();

	const auto f = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings |
		ImGuiWindowFlags_NoInputs;

	ImGui::GetStyle().AntiAliasedFill = true;
	ImGui::GetStyle().AntiAliasedLines = true;


	if (bShowMenu)
	{
		bool bShow = true;

		ImGui::Begin("Root", nullptr, f);

		ImGui::PushFont(g_font);

		ImGui::ShowDemoWindow(&bShow);

		ImGui::PopFont();

		ImGui::End();
	}

	ImGui::EndFrame();
	ImGui::Render();

	pDeviceContext->OMSetRenderTargets(1, &pTargetRT, nullptr);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	return fnIDXGISwapChainPresent(_chain, syncInterval, flags);
}

void PrintRVA()
{
	std::cout << "[+] pDevice              :: 0x" << std::hex << pDevice << std::endl;
	std::cout << "[+] pDeviceContext       :: 0x" << std::hex << pDeviceContext << std::endl;
	std::cout << "[+] pDeviceContextVTable :: 0x" << std::hex << pDeviceContextVTable << std::endl;
	std::cout << "[+] fnDXGISwapChainPres  :: 0x" << std::hex << fnIDXGISwapChainPresent << std::endl;
}

bool InitializePresent(IDXGISwapChain* pChain, UINT SyncInterval, UINT Flags)
{
	HRESULT result;

	result = pChain->GetDevice(__uuidof(ID3D11Device), (PVOID*)&pDevice);
	if (FAILED(result))
	{
		return false;
	}

	pDevice->GetImmediateContext(&pDeviceContext);
	pSwapChain = pChain;

	DXGI_SWAP_CHAIN_DESC swapChainDesc;
	pSwapChain->GetDesc(&swapChainDesc);

	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	(void)io;

	io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
	window = swapChainDesc.OutputWindow;

	originWndProcHandler = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)hWndProc);

	ImGui_ImplWin32_Init(window);
	ImGui_ImplDX11_Init(pDevice, pDeviceContext);

	ImGui::GetIO().ImeWindowHandle = window;

	ConfigureGUIStyle();

	ID3D11Texture2D* pBackBuffer;
	pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);

	if (pBackBuffer != nullptr)
	{
		pDevice->CreateRenderTargetView(pBackBuffer, nullptr, &pTargetRT);
		pBackBuffer->Release();
	}

	bPresentInitialized = true;

	return true;
}

void ConfigureGUIStyle()
{
	if (!m_default)
	{
		m_default = ImGui::GetIO().Fonts->AddFontDefault();
	}

	ImGuiStyle* style = &ImGui::GetStyle();

	style->WindowPadding = ImVec2(15, 15);
	style->WindowRounding = 5.0f;
	style->FramePadding = ImVec2(5, 5);
	style->FrameRounding = 4.0f;
	style->ItemSpacing = ImVec2(12, 8);
	style->ItemInnerSpacing = ImVec2(8, 6);
	style->IndentSpacing = 25.0f;
	style->ScrollbarSize = 15.0f;
	style->ScrollbarRounding = 9.0f;
	style->GrabMinSize = 5.0f;
	style->GrabRounding = 3.0f;

	style->Colors[ImGuiCol_Text] = ImVec4(0.80f, 0.80f, 0.83f, 1.00f);
	style->Colors[ImGuiCol_TextDisabled] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);

	style->Colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
	style->Colors[ImGuiCol_Border] = ImVec4(0.80f, 0.80f, 0.83f, 0.88f);
	style->Colors[ImGuiCol_BorderShadow] = ImVec4(0.92f, 0.91f, 0.88f, 0.00f);
	style->Colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(1.00f, 0.98f, 0.95f, 0.75f);
	style->Colors[ImGuiCol_TitleBgActive] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
	style->Colors[ImGuiCol_MenuBarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
	style->Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_CheckMark] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
	style->Colors[ImGuiCol_SliderGrab] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
	style->Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_Button] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style->Colors[ImGuiCol_ButtonActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_Header] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	style->Colors[ImGuiCol_HeaderHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_HeaderActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style->Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style->Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style->Colors[ImGuiCol_PlotLines] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style->Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style->Colors[ImGuiCol_PlotHistogram] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style->Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style->Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.25f, 1.00f, 0.00f, 0.43f);

	ImGuiIO io = ImGui::GetIO();

	io.Fonts->AddFontDefault();

}